
//package blackjack;
//import java.util.Scanner ;
//
//public class NewClass {
//    static Game game =new Game();
//    public static void main (String []arg){
//     game.generateCards();
//     game.playerInfo();
//}}
